package com.lao.actionKeywords;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ActionKeywords {
	
	static ChromeDriver driver;

	//openBrowser()
	public static void openBrowser()
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
	}
	
	
	//goToUrl()
	public static void goToUrl()
	{
		driver.get("https://opensource-demo.orangehrmlive.com/index.php");
	}
	
	//enterUserName()
	public static void enterUserName()
	{
		WebElement userName=driver.findElement(By.id("txtUsername"));
		userName.sendKeys("Admin");
	}
	
	//enterPassword()
	public static void enterPassword()
	{
		WebElement password=driver.findElement(By.id("txtPassword"));
		password.sendKeys("admin123");
	}
	
	//clickLogin()
	public static void clickLogin()
	{
		WebElement loginButton=driver.findElement(By.id("btnLogin"));
		loginButton.click();
	}
	
}
