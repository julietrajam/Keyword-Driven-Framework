package com.lao.executionCore;

import java.io.IOException;

import com.lao.actionKeywords.ActionKeywords;
import com.lao.utilities.ExcelUtilities;

public class Engine {
	
	public static void main(String[] args) throws IOException {
		
		ExcelUtilities utilities=new ExcelUtilities();
		utilities.readExcelFile("src\\test\\resources\\testdata.xlsx");
		
		for(int row=1;row<=5;row++) {
		String keyword=utilities.getValuesFromExcel(row, 3);
		
		if(keyword.equalsIgnoreCase("openBrowser")) {
			ActionKeywords.openBrowser();
			}else if(keyword.equalsIgnoreCase("goToUrl")) {
				ActionKeywords.goToUrl();
			}else if(keyword.equalsIgnoreCase("enterUserName")) {
				ActionKeywords.enterUserName();
			}else if(keyword.equalsIgnoreCase("enterPassword")) {
					ActionKeywords.enterPassword();
			}else if(keyword.equalsIgnoreCase("clickLogin")) {
						ActionKeywords.clickLogin();
			}
		
	
	   }
	}
}
